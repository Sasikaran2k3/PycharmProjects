sasi bro here you can code 
in navigation bar there are 5 pages i.e home,help,news,case and about
each page in the navigation bar has each file as you can see
i have done this at vs code see that you can do in pycharm
otherwise install vs code
you should install html as extension then it will work for html,css and php
and install open in browser as extension 
after coding save all will available in file i think
save all and go to index.html do right click and select open in other browser and select browser
if you have dout na call me 
contact no:6369029718
or 
mail:21102104@rmd.ac.in
